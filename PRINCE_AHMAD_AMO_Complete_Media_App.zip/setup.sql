-- PRINCE AHMAD (AMO) Complete Media App
-- Run this whole script in Supabase > SQL Editor.
-- It is safe to run again: policies are dropped before being recreated.

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.media_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  media_type text not null check (media_type in ('audio','video','photo')),
  storage_path text not null,
  public_url text not null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.media_items enable row level security;

-- Admin can read only their own admin row. This lets the app detect admin access.
drop policy if exists "Admins can read own admin row" on public.admin_users;
create policy "Admins can read own admin row"
on public.admin_users for select
to authenticated
using (user_id = auth.uid());

-- Everyone can view the public media gallery.
drop policy if exists "Public can read media" on public.media_items;
create policy "Public can read media"
on public.media_items for select
to anon, authenticated
using (true);

-- Only listed admins can add, edit or delete media records.
drop policy if exists "Admins can insert media" on public.media_items;
create policy "Admins can insert media"
on public.media_items for insert
to authenticated
with check (
  exists (select 1 from public.admin_users a where a.user_id = auth.uid())
  and created_by = auth.uid()
);

drop policy if exists "Admins can update media" on public.media_items;
create policy "Admins can update media"
on public.media_items for update
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "Admins can delete media" on public.media_items;
create policy "Admins can delete media"
on public.media_items for delete
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Create a public bucket so visitors can play/view published gallery items.
insert into storage.buckets (id, name, public, file_size_limit)
values ('prince-ahmad-media', 'prince-ahmad-media', true, 52428800)
on conflict (id) do update set public = true;

drop policy if exists "Public can view Prince Ahmad media files" on storage.objects;
create policy "Public can view Prince Ahmad media files"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'prince-ahmad-media');

drop policy if exists "Admins can upload Prince Ahmad media files" on storage.objects;
create policy "Admins can upload Prince Ahmad media files"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'prince-ahmad-media'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

drop policy if exists "Admins can delete Prince Ahmad media files" on storage.objects;
create policy "Admins can delete Prince Ahmad media files"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'prince-ahmad-media'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

-- IMPORTANT:
-- Your user ID was already added to admin_users in the earlier setup.
-- If you ever need to add another admin, first get that user's UUID from
-- Supabase Authentication > Users, then run:
-- insert into public.admin_users (user_id) values ('USER-UUID-HERE')
-- on conflict (user_id) do nothing;
